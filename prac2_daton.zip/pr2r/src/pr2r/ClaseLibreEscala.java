package pr2r;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

class ClaseLibreEscala {

	

	 /****************************
		RED LIBRE DE ESCALA
		Utilizar� el mismo csv de nodos generado por la aleatoria
	  */
	static void libreDeEscala(int nodos,int m){
	   String texto = "Source;Target;Type\n";
       int i,aux;
       int k, t = 0, contadorLista = 0, p = 0, nodo1, nodo2, nodoAleatLista;
       Nodo nodo= new Nodo();
       Vector auxiliar = new Vector(2);
       Vector listaAristas[] = new Vector[1000000];
		Nodo listaNodos[]= new Nodo[nodos];
		boolean conectado = false;
		for (int x=0; x<nodos; x++){
			listaNodos[x] = new Nodo();
			listaNodos[x].setIdNodo(x+1);
		}
       //Generar aristas
       
       //los 4 o 5(en funcion de m) primeros nodos entre si
		for(k=1; k<=(m+1); k++){
			for(int l=k+1; l<=m+1; l++){
				texto += k+";"+l+";"+"Undirected"+"\n";
				Vector arista = new Vector(2);
				arista.addElement(listaNodos[k-1].getIdNodo());
				arista.addElement(listaNodos[l-1].getIdNodo());
				listaAristas[contadorLista] = arista;
				contadorLista++;
				listaNodos[k-1].aumentarGrado();
				listaNodos[l-1].aumentarGrado();
			}
		}
		if (m == 3) k=4;//sale con valor 5 del for
		else k = 5;
		int T =nodos-(m + 1);
		double probabilidad;
		double probCumpla;
		int nuevoNodo= m+1;
		//resto de aristas
		System.out.println("Procesados nodos iniciales con " + m + " enlaces");
		System.out.println("Procesando resto de nodos...");
		while (t < T){
			k++;//para todos los nuevos nodos que se tienen que a�adir	
			//genero m enlaces 
				for (int n = 0; n < m; n++){	
					aux = (int) (Math.random()*k + 1); //posible nodo al que conectarse, numero entre 1 y 5 en la primera iteracion
					while (aux == k) // para evitar que un nodo este conectado consigo mismo
						aux = (int) (Math.random()*k + 1);
					//recorro la lista de aristas para ver si ya est� esa arista(tupla)
					while ((p < contadorLista)){
						nodo1 =(int)(listaAristas[p].elementAt(0));
						nodo2 =(int)(listaAristas[p].elementAt(1));
						if (((k == nodo1) && (aux == nodo2)) || ((k == nodo2) && (aux == nodo1))){
							aux = (int) (Math.random()*k+1);
							while (aux == k) // para evitar que un nodo este conectado consigo mismo
								aux = (int) (Math.random()*k + 1);
							p = 0;
						}
						else{
							p++;	
						}
					}
					//Cojo un indice (nodo) aleatorio de todos los que llevo excepto el nuevo que entra
					nodoAleatLista = (int) (Math.random()*k);
					while (!conectado){						
						//me quedo con su probabilidad
						probabilidad=((double)listaNodos[nodoAleatLista].getGrado()/(double)contadorLista);
						probCumpla=Math.random();
						if(probCumpla<=probabilidad){
							Vector arista = new Vector(2);
							arista.addElement(k);
							arista.addElement(aux);
							listaAristas[contadorLista] = arista;
							contadorLista++;
							p = 0;
							texto += k+";"+aux+";"+"Undirected"+"\n";
							nuevoNodo++;
							conectado = true;
						}
						else
							nodoAleatLista = (int) (Math.random()*k);	
					}
					
					conectado = false;	
				}
			t++;
		}

       try{
    	String nombreCarpeta = "aristasLibreEscala";
    	String nombreArchivo4 = "aristasLDE_" + nodos + "_nodos_" + m + "_enlaces.csv";
   		File carpeta = new File(nombreCarpeta);
   		carpeta.mkdir();
   		File fichero= new File(carpeta,nombreArchivo4);   		
        FileWriter fwriter3 = new FileWriter(fichero);
        fwriter3.write(texto);
        fwriter3.flush();
        fwriter3.close();
           
       }catch (IOException e){

       }
       System.out.println("Libre de escala "+ nodos + " nodos y "+ m + " enlaces acabada");	
	}
	
	
}
